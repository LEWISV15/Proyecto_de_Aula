/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.unicolombo.pb20232;
import co.edu.unicolombo.pb20232.ventanas.VentanaPrincipal1;
import java.util.Scanner;
/**
 
 * @author Luis Maldonado
 */
public class Principal {
    
    
    public static void main(String[] args) {
        System.out.println("Hola ");
        VentanaPrincipal1 miVentana = new VentanaPrincipal1();
        miVentana.setTitle("GUIA 1");
        miVentana.setLocationRelativeTo(null);
        miVentana.setVisible(true);
        Scanner leer = new Scanner(System.in);
        }
    public String NEKOMA;
    public String SOCORRO;
    public String MASCULINO;
    public String RRORO;
    public String TARDE;
    
    public void visualizar(String nombre1, String sede1, String tipodejuego1, String entrenador, String horarios){
        
    nombre1 = NEKOMA;
    sede1 = SOCORRO;
    tipodejuego1 = MASCULINO;
    entrenador = RRORO;
    horarios = TARDE;

    }
}
