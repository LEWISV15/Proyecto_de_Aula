/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.unicolombo.pb20232;

import java.util.Vector;

/**
 *
 * @author Luis Maldonado
 */

public class Saldos {
     public int saldo = 1000;
     public int resta = saldo-500;
     public int suma = saldo+1000;
     
      
     public void datos_del_saldo(int suma, int resta){
      resta = saldo-500;
      suma = saldo+500;
       
       }
     
   
     
 
    
}
